# LEGONRUSH IPS Road Commercial Corridor Pack

This is a standalone work package for the IPS Road commercial frontage opposite the school/campus area. It is separate from the UPSA campus landmark reconstruction.

## Contents
- `LEGONRUSH_IPS_Road_Commercial_Corridor_Brief.docx` — detailed scope, reference analysis and implementation plan.
- `CLAUDE_CODE_MASTER_PROMPT.md` — ready-to-paste master prompt.
- `reference_images/` — supplied still references renamed descriptively.
- `270_degree_corridor_reference_video.mp4` — supplied corridor video.
- `video_keyframes/` — representative extracted frames for quick review.
- `REFERENCE_CONTACT_SHEET.jpg` — image overview.

Placement and dimensions must be established from repository geography and evidence; do not invent coordinates. Protect existing roads, routes, access points and unrelated landmarks. Do not deploy without approval.
