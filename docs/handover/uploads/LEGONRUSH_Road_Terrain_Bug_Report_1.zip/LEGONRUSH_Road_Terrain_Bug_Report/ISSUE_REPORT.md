# LEGONRUSH Road and Terrain Regression Report

## Purpose
Visual bug report assembled from the screenshots attached in the conversation. The originals are preserved unchanged in `images/`; selected annotated copies are in `annotated/`.

## Observed issues
1. Long raised horizontal strips/bars cross roads and paths in several screenshots.
2. Road edges appear to overlap grass or other terrain surfaces in places.
3. Some road/ground boundaries show seams, gaps, or abrupt geometry transitions.
4. The user also reports road–grass flickering and noticeable gameplay lag.

## Suspected timing
The user reports that the raised bars were not present earlier and may have appeared after commits made in the last 24 hours. This is a hypothesis, not a confirmed cause.

## Investigation requested
- Inspect recent Git history for changes to road, terrain, curb, sidewalk, wall, collision, and environmental geometry.
- Trace the visible bars to the responsible source code or generated data.
- Correct only unintended geometry and preserve legitimate campus structures, roads, drainage, markings, and collision boundaries.
- Investigate flicker and performance separately; do not sacrifice visual quality without evidence.
- Run the existing type check, route tests, build, and smoke tests.

## Live game
https://rudolphdeladem.github.io/legonrush-world/play/

## Screenshot inventory
The `images/` directory contains the original screenshots with unchanged image bytes. `annotated/` contains selected copies with red pointers to likely visible defects. Pointers are visual aids, not proof of the underlying technical cause.


