# LEGONRUSH visual bug report

- `images/`: original screenshots, unchanged.
- `annotated/`: selected copies with red pointers to visible bars/seams.
- `ISSUE_REPORT.md`: concise description and investigation checklist.

The annotations indicate visible symptoms only. Diagnose the actual cause from the project code and recent Git history.
