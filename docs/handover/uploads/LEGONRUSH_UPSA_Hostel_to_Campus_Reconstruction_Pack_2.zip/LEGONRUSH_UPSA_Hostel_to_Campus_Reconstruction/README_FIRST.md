# LEGONRUSH UPSA Hostel-to-School Reconstruction Pack

## Start here
1. Read `LEGONRUSH_UPSA_Hostel_to_UPSA_Campus_Reconstruction_Brief.docx` completely.
2. Read `CLAUDE_CODE_MASTER_PROMPT.txt` completely before making any implementation decision.
3. Read `ONLINE_SOURCES.md` and `REFERENCE_REGISTER.csv`.
4. Inspect every original image in `reference_images/user_uploaded_streetview/`, and then inspect all images in `reference_images/current_game/` and `reference_images/generated_diagrams/`. Contact sheets are indexes only; they do not replace individual image inspection.
5. The master prompt requires Claude to inventory and review every task-related upload and related UPSA/IPS Road/UPSA Junction/hostel/VC/UGBS reference pack available in the environment before editing code.

## Intended scope
Reconstruct the continuous road and playable environment from the UPSA Hostel-area / IPS Road approach, through UPSA Main Gate, and onward inside campus to the mapped UPSA school/academic area. The route must not stop at the gate or merely at the first internal landmark if the academic area is further inside.

## Evidence rules
- Repository geographic data controls topology, stable IDs, route connectivity and existing gameplay compatibility.
- User-supplied real-world screenshots control visible roadside appearance where the views support it.
- Official UPSA sources help verify names and building identity.
- OSM/traceable maps supplement geospatial context.
- Current-game screenshots diagnose implementation gaps; they are not real-world maps.
- Route-sequence diagrams are conceptual and not to scale.

Do not push to `main` or deploy to production without explicit user approval.
