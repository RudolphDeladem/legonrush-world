# Online sources and links

Accessed/reviewed 12 October 2026. These are identity/location/context anchors; use project data for exact implementation geometry.

## S1 — UPSA official homepage
- URL: https://upsa.edu.gh/
- Use: Official institutional reference for campus identity and current navigation to official resources.

## S2 — UPSA official article: building names on campus (2017)
- URL: https://upsa.edu.gh/upsa-unveils-building-names-and-busts-on-campus/
- Use: Confirms presence of Central Administration, lecture blocks, clinic and five-storey library complex; older article, so use as naming context not present-day completion status.

## S3 — UPSA official Student Services / campus info
- URL: https://upsa.edu.gh/students/student-services/
- Use: Names the Central Administration Block and discusses the campus/hostel context and nearby institutions.

## S4 — UPSA Annual Report 2024
- URL: https://upsa.edu.gh/docx/publications/annual-report-2024.pdf
- Use: Documents a Model Police Station, pedestrian walkway/drains behind Amon Kotei Hostel, and campus construction projects; this is a dated report and may not reflect today’s exact completion state.

## S5 — UPSA 2016 Annual Report (historic gate/wayfinding context)
- URL: https://upsa.edu.gh/docx/publications/annual-report-2016.pdf
- Use: Describes pedestrian route to the pedestrian gate near bus stop, security shelter near the main entrance, grating over a drain and lay-by near security post. Treat as historical design notes only.

## S6 — Wikimedia Commons: Main Gate (UPSA).jpg
- URL: https://commons.wikimedia.org/wiki/File:Main_Gate_(UPSA).jpg
- Use: Openly licensed main-gate photograph by Manson04, dated 22 May 2021; page identifies CC BY-SA 4.0. Gate photo is appearance reference, not a current survey.

## S7 — Wikimedia Commons: Main Gate (UPSA) 1.jpg
- URL: https://commons.wikimedia.org/wiki/File:Main_Gate_(UPSA)_1.jpg
- Use: Second angle of the main gate by Manson04, dated 22 May 2021; CC BY-SA 4.0. Shows signage, canopy, gatehouse, traffic barrier/approach.

## S8 — Wikimedia Commons UPSA image collection
- URL: https://commons.wikimedia.org/wiki/Category:University_of_Professional_Studies_in_Accra
- Use: Open photo list including Campus, Central Administration, Joshua Alabi Library, Auditorium and Justice Aryeetey Building references.

## S9 — OpenStreetMap campus object / Mapcarta UPSA page
- URL: https://mapcarta.com/W309660062
- Use: OpenStreetMap-derived campus locator: approx. 5.66155 N, -0.16638 W. This is a campus-area anchor, not the exact gate coordinate or a complete surveyed path.

## S10 — OpenStreetMap direct map around UPSA
- URL: https://www.openstreetmap.org/#map=17/5.66155/-0.16638
- Use: Use for orientation and to inspect mapped roads/buildings; confirm licensing and source attribution if data is imported.

## S11 — Google Maps: UPSA search link
- URL: https://www.google.com/maps/search/?api=1&query=University+of+Professional+Studies+Accra
- Use: Interactive map entry point. Street View imagery may be older/incomplete; compare multiple angles and map data.

## S12 — User-supplied Google photosphere
- URL: https://www.google.com/local/place/fid/0xfdf9c91e05dd553:0x44fa18abb0bf922c/photosphere?iu=https://streetviewpixels-pa.googleapis.com/v1/thumbnail?panoid%3D_fC_-YnWkh1Yd2VAnMR9xQ%26cb_client%3Dlu.gallery.gps%26w%3D160%26h%3D106%26yaw%3D18.997597%26pitch%3D0%26thumbfov%3D100&ik=CAISFl9mQ18tWW5Xa2gxWWQyVkFuTVI5eFE%3D
- Use: User-provided Street View/photosphere context link around the wider hostel/road environment.

## S13 — Official UPSA social post showing main entrance gate (2019)
- URL: https://x.com/upsaccra/status/1085855060242952192
- Use: Institutional image reference for the blue-and-white entrance arch, fascia and approach. Open link in browser; not used as survey geometry.

## S14 — Official UPSA social post showing aerial campus view (2019)
- URL: https://x.com/upsaccra/status/1117815880174510082
- Use: Aerial visual reference for building massing and campus landscape arrangement; image is historical, so verify against current map/build data.

## S15 — Official UPSA aerial campus view (2023)
- URL: https://x.com/upsaccra/status/1734095905358254371
- Use: A wider aerial view showing general campus density, sports/campus context; do not use perspective alone to set building coordinates.
