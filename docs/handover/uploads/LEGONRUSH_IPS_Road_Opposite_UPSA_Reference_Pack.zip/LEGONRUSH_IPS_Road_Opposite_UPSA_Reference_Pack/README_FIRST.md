LEGONRUSH — IPS ROAD OPPOSITE UPSA REFERENCE PACK

Start with LEGONRUSH_IPS_Road_Opposite_UPSA_Reconstruction_Brief.docx.
Contains the complete implementation brief, distinct asset specifications, source-evidence rules, acceptance checklist and Claude Code master prompt.

Folders:
- reference_images/: supplied still images, renamed for clarity
- reference_video/ips_road_270_degree_streetview.mp4: full 270° screen recording
- REFERENCE_CONTACT_SHEET.jpg: quick image index

Important: this is a separate task pack for the commercial frontage opposite UPSA. Do not merge it into the UPSA campus landmark pack. Use repository geography for placement and treat photos/video as visual evidence, not exact coordinates.
