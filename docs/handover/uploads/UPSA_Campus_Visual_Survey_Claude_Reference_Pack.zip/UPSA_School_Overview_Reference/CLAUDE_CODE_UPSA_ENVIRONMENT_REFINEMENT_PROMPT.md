# Claude Code task: refine the complete UPSA campus environment in LEGONRUSH

You are working in `RudolphDeladem/legonrush-world`. First inspect `CLAUDE.md`, `README.md`, `docs/migration/`, the current geography authority files, and all relevant UPSA/campus building code before editing. The attached reference pack is evidence to study, not a license to invent coordinates.

## Objective
Refine the **whole University of Professional Studies, Accra (UPSA) campus environment and immediate entrance/access context** in LEGONRUSH so the building placement, names, height/story counts, footprints, rooflines, access roads, parking courts, sports areas, pedestrian paths, landscaping, and relationships between adjacent structures better match the real campus. The goal is a coherent complete campus environment, not just isolated hero buildings.

## Evidence pack
Use every part of `UPSA_School_Overview_Reference_Pack.zip`:
- `frames/`: 214 timestamped screenshots, sampled at one-second intervals from the supplied 3m34s screen recording.
- `contact_sheet_*.jpg`: four readable contact sheets grouped in order, plus `contact_sheet_all_frames.jpg`.
- `frame_index.csv`: timestamp and targeted notes for selected moments.
- `UPSA_Campus_Visual_Survey_and_Claude_Rebuild_Brief.docx` and matching PDF: findings, building inventory, positional evidence, uncertainty, acceptance criteria.
- `MAP_AND_SOURCE_LINKS.md`: current Google Maps, Google Earth, OpenStreetMap, and official UPSA links.

Start by reviewing the all-frame contact sheet, then use relevant original frames at full size. The most useful moments are called out in the brief. Keep the timestamp as the stable evidence identifier.

## Critical date warning
The MP4 file was a screen recording made on 13 October 2026, but the aerial footage’s original capture date is not visible. It carries a `DroneStories` watermark and includes construction scaffolding. UPSA states officially that the ten-storey Twin Towers were commissioned on 18 December 2024. **Do not treat the visible construction state as the current campus state.** Use the clip for shape, pre-completion footprint/context and spatial adjacency; validate present-day geometry and completed façade against current available imagery and official UPSA sources.

## Current reference facts that must not be overwritten by old imagery
- UPSA officially commissioned its **ten-storey Multipurpose Twin Towers** on 18 December 2024; the new building was named after outgoing Vice-Chancellor Prof. Abednego F. O. Amartey. The project comprises two blocks, ten levels each, with bridges linking the blocks over five levels.
- **Nii Amon Kotei Hostel** is a ten-storey, 1,664-bed facility commissioned in March 2023.
- **Joshua Alabi Library** is described by UPSA as a six-storey library complex (older source refers to five storeys; use current official/visual evidence and leave exact floor count flagged only if a conflict remains).
- **Justice Aryeetey Building / Lecture Block Complex** is described as six storeys in UPSA’s campus development article.
- The **Student Centre** is described by UPSA as a six-storey building.
- The **Kofi Ohene-Konadu Auditorium** and **Rev. J. K. Antwi Astro Turf** are official facility names. UPSA describes the auditorium as a 3,550-capacity facility and the Astro Turf as a 500-seater stadium.
- **Opoku Ampomah / Central Administration Block** is identifiable by the roofline sign “UNIVERSITY OF PROFESSIONAL STUDIES ACCRA” in the supplied footage. The footage supports its exterior proportions, blue glass, white/light facade, rooftop structure, entry/gate and front parking; it does not establish an official floor count.
- A visible building sign reads **“PROFESSIONAL CHRISTIAN UNION BUILDING.”** Do not conflate that building with the nearby Twin Towers or adjacent blocks merely because they appear in the same shot.
- UPSA says the Ewuntoma Clinic/Medical Centre is in the north-eastern part of campus. The clip alone does not let us confidently assign this name to a specific visible building.

## Geographic and repo safeguards
- Inspect and follow the project’s existing source-of-truth rules. Relevant canonical files may include `data/geography/legon-master.geojson`, `data/geography/legon-access.geojson`, `data/geography/registry/access.json`, `data/legon.osm`, `src/data/legon-map.json`, geography corrections, `data/geography/sources/ug-campus-map-pois.json`, `scripts/geography/*`, and the current building/world renderer modules. Confirm current paths before editing.
- Preserve all existing campus geography outside the UPSA target area, all roads/path widths and paths that are correct, campus boundary logic, building entrances/access points, race/challenge routes, route identifiers, ghosts, leaderboard records, collision logic, route graph connectivity, and all existing game systems.
- Never alter route geometry to make the campus buildings fit. Never shift canonical points, gates, or campus boundary without matching map/data support. Use current satellite imagery and available official sources to settle placement. A Google map search link is included, but a dynamically loaded map screenshot is not a substitute for repository source-of-truth data.
- Screen coordinates and left/right movement in the drone video are **not geospatial coordinates**. The camera rotates and changes altitude. Use co-visibility to understand what is adjacent; assign cardinal position only after checking north-up satellite/map imagery or canonical coordinates.
- Count storeys from official sources wherever possible. For visually estimated/unnamed blocks, record a confidence status and do not assign an official building name until it is verified from signage, a trusted map label, or an official source.
- Do not use the YouTube/DroneStories watermark, subscribe overlay, app chrome or black bars as 3D-world assets.

## Required investigation and implementation
1. Inspect existing buildings and the actual UPSA coverage area; make an evidence matrix mapping current in-game objects/coordinates to real-world entities and confidence.
2. Open the provided Google Maps / Earth / OSM links in a browser if available. Compare the most recent satellite imagery with the video, official building names, and canonical project geography. Record which sources were actually accessible and dates shown; do not claim to have browsed a source you could not open.
3. Identify and verify the key clusters: Central Administration and front gate; Twin Towers and auditorium/parking/driveways; Astro Turf and its surrounding academic blocks; the Professional Christian Union Building; long multi-storey buildings and courtyard/parking areas; hostels; library and clinic if within the target extent; and the immediate road/access context. Add the newly built model police-station/access-road/footbridge/drain features only where current source evidence and map geometry confirm them.
4. For every candidate building, log: verified name or temporary label, map/geo position and footprint source, estimated/official storeys, facade/roof profile, main visible entrance, neighbouring buildings, access/parking/path relationships, evidence frames/timestamps, confidence, and unresolved questions.
5. Update the whole UPSA campus environment coherently: footprints and placements first; height and roof silhouette second; facade windows/colour/major features third; surface/landscape/parking and access continuity fourth. Use reusable geometry/material patterns instead of one-off hacks. Keep frame rate and draw calls in mind.
6. Where imagery and map disagree, state the conflict and favour current, geographically grounded data for placement and newest official evidence for completed building state; do not blindly copy an older construction screenshot or force all sources to agree.
7. Run type checks, tests (especially geography/access/routes/collisions), production build, and visual browser smoke tests. Inspect the campus from multiple angles and at normal gameplay distance, not only a close-up. Verify no flicker, z-fighting, floating meshes, intersections through roads, blocked entrances, broken paths, or route regressions.
8. Report the verified building inventory, the changed files, root causes of any major placement/name errors, test/build results, a before/after screenshot set, remaining uncertainties, and the commit hash.

## Completion / git safety
Work autonomously without asking for intermediate approval. Make changes on a working branch. Do **not** push to `main`, merge to `main`, or deploy/trigger production publishing without explicit approval. If the configured safe workflow allows, commit and push only the working branch after all checks pass; otherwise leave a clean, reviewable diff and state that no branch push was performed.

## Acceptance criteria
- The whole UPSA area reads as a connected campus rather than scattered isolated building models.
- Major official building names map to the correct structures; no UGBS/UPSA-hostel/other-campus identity confusion.
- Twin Towers are represented as the completed two-block, ten-storey facility rather than an unfinished scaffold state.
- Official story counts are respected; inferred counts are marked as estimates.
- Current positions and road/access relationships are geospatially verified as far as available data permits.
- Correct roads, entrances, pedestrian paths, parking surfaces, sport facilities, green areas and connecting spaces remain continuous and traversable.
- All existing routes, route records/ghosts, campus boundaries and unrelated geography remain intact.
- Tests/build/visual smoke tests pass, with final branch/commit and residual uncertainty clearly reported.
