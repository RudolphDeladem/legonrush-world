# UPSA Map and Source Links

Prepared 13 October 2026. Open these in a browser while reviewing `legonrush-world`. Google Maps is a dynamic page; the link opens a search rather than embedding a fixed, date-stamped satellite image.

- [UPSA campus (Google Maps search)](https://www.google.com/maps/search/?api=1&query=University+of+Professional+Studies+Accra)
- [UPSA campus (Google Earth search)](https://earth.google.com/web/search/University+of+Professional+Studies,+Accra,+Ghana/)
- [UPSA campus (OpenStreetMap search)](https://www.openstreetmap.org/search?query=University%20of%20Professional%20Studies%20Accra)
- [Abednego F. O. Amartey Multipurpose Twin Towers](https://www.google.com/maps/search/?api=1&query=UPSA+Abednego+F.+O.+Amartey+Multipurpose+Twin+Towers)
- [Nii Amon Kotei Hostel](https://www.google.com/maps/search/?api=1&query=Nii+Amon+Kotei+Hostel+UPSA)
- [Joshua Alabi Library](https://www.google.com/maps/search/?api=1&query=Joshua+Alabi+Library+UPSA)
- [Kofi Ohene-Konadu Auditorium](https://www.google.com/maps/search/?api=1&query=Kofi+Ohene-Konadu+Auditorium+UPSA)
- [Rev. J. K. Antwi Astro Turf](https://www.google.com/maps/search/?api=1&query=Rev+J+K+Antwi+Astro+Turf+UPSA)
- [Justice Aryeetey Building](https://www.google.com/maps/search/?api=1&query=Justice+Aryeetey+Building+UPSA)
- [Ewuntoma Medical Centre](https://www.google.com/maps/search/?api=1&query=Ewuntoma+Medical+Centre+UPSA)
- [Professional Christian Union Building](https://www.google.com/maps/search/?api=1&query=Professional+Christian+Union+Building+UPSA)
- [Official UPSA current Twin Towers article (19 Dec 2024)](https://upsa.edu.gh/president-akufo-addo-commissions-new-upsa-twin-towers/)
- [Official UPSA Nii Amon Kotei Hostel article (16 Mar 2023)](https://upsa.edu.gh/education-minister-commissions-new-ultra-modern-hostel-at-upsa/)
- [Official UPSA auditorium and Astro Turf names (12 Aug 2021)](https://upsa.edu.gh/upsa-unveils-names-for-new-auditorium-and-astro-turf/)
- [Official UPSA building names (12 Aug 2017)](https://upsa.edu.gh/upsa-unveils-building-names-and-busts-on-campus/)
- [Official UPSA campus development feature (18 Feb 2020)](https://upsa.edu.gh/feature-the-manifest-makeover-of-upsa/)
- [Official UPSA annual report 2024 (campus infrastructure)](https://upsa.edu.gh/docx/publications/annual-report-2024.pdf)
- [Official UPSA 2023 leadership/campus infrastructure article](https://upsa.edu.gh/alabi-sowed-the-seeds-okoe-amartey-nurtured-the-sammy-darko-upsa-experience/)
- [Official UPSA Student Services / Clinic campus location](https://upsa.edu.gh/students/student-services/)

## Evidence interpretation

- The screen recording contains a `DroneStories` watermark and visible subscribe overlay. The actual aerial footage date is not encoded in the visible frames. The file metadata only records the screen recording as captured on 13 October 2026; it does not establish the capture date of the footage shown inside it.
- The footage clearly shows construction scaffolding around the Twin Tower area. UPSA’s official article says the ten-storey Twin Towers were commissioned on 18 December 2024. Therefore the clip’s aerial imagery is older than that completion state, regardless of the screen recording date.
- Do not infer compass directions from left/right positions across the video: the drone rotates and changes altitude. Only same-frame relationships are reliable until georeferenced against map data.
