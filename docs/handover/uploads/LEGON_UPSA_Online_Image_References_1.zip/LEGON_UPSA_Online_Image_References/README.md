# LEGONRUSH — UPSA Junction, GOIL & UGBS Online Image Reference Pack

This is a supplementary online-reference pack for the Legon–UPSA Junction / GOIL Filling Station / UGBS Graduate Building world-development brief.

## Important limitation
Direct image downloads from the source websites could not be completed in this runtime (network/DNS fetch failures). To avoid pretending that remote images were downloaded, this pack contains a browser-viewable gallery and a source list with direct links. The gallery loads the linked image only when opened with an internet connection. It does **not** contain copies of those remote images.

## Best sources
1. **GOIL station at UPSA Junction** — local listing with coordinates and visitor photos/references: https://gh.near-place.com/goil-filling-station-upsa-junction-n4-accra
2. **GOIL UPSA Junction** — station description and map listing: https://vymaps.com/GH/Goil-Filling-Station-60197/
3. **GOIL official gallery** — use for general brand/canopy design only; most photos are other branches, not confirmed as the UPSA station: https://www.goil.com.gh/gallery/
4. **UGBS official site** — campus tour includes a Graduate School image/category: https://www.ugbs.ug.edu.gh/home
5. **UGBS Graduate Building official location confirmation** — opposite the GOIL station, Legon–Madina Highway: https://old1.ug.edu.gh/events/inauguration-ugbs-multi-purpose-graduate-building
6. **UGBS Graduate Campus map entry** — OSM-backed location and nearby context: https://mapcarta.com/W797937346
7. **Waze road-map tile** — shows N4 / Legon–East Road and GOIL site relative to IPS Road: https://www.waze.com/row-tiles/live/base/17/65471/63471/tile.png?highres=true
8. **Wikimedia Commons GOIL station photo** — general GOIL reference, NOT the exact UPSA branch; check attribution/license on source page: https://commons.wikimedia.org/wiki/File:GOIL_Tankstelle_Accra_2013_B003.jpg

## Recommended use
- Prioritize user-supplied photos and exact local street-level references for geometry.
- Treat official GOIL gallery images as branding/material references unless the location is verified.
- Do not use the generic Wikimedia GOIL photo as a direct model of the UPSA station.
- Keep all geometry estimates provisional until checked against map/satellite/street-level imagery.
